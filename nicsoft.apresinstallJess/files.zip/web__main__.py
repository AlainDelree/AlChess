"""
nicsoft/web/__main__.py — Point d'entrée principal NicLink.
"""
import os
import time
import random
import sys
import subprocess
import threading
import webbrowser
import chess
import logging
from nicsoft.web.server import start_server, set_app_state, get_menu_action, send_event
from nicsoft.web import server as web_server

# ── Logger timing ─────────────────────────────────────────────────────────────
# Activer avec : NICLINK_LOG=DEBUG python -m nicsoft.web
_timing_logger = logging.getLogger("niclink.timing")

def _setup_logging():
    level = os.environ.get("NICLINK_LOG", "").upper()
    if level == "DEBUG":
        handler = logging.StreamHandler()
        handler.setFormatter(logging.Formatter("%(message)s"))
        _timing_logger.addHandler(handler)
        _timing_logger.setLevel(logging.DEBUG)
        _timing_logger.propagate = False
        print("[LOG] Mode DEBUG activé — timings visibles")
    else:
        _timing_logger.setLevel(logging.CRITICAL)  # silencieux par défaut


def _stop_modem_manager():
    """Stoppe ModemManager s'il tourne — évite les interférences USB avec l'échiquier."""
    try:
        result = subprocess.run(
            ["sudo", "systemctl", "stop", "ModemManager"],
            capture_output=True, timeout=5
        )
        if result.returncode == 0:
            print("[NicLink] ModemManager arrêté.")
    except Exception:
        pass  # pas de sudo configuré ou ModemManager absent — pas bloquant


def _start_modem_manager():
    """Relance ModemManager à la fin de NicLink."""
    try:
        subprocess.run(
            ["sudo", "systemctl", "start", "ModemManager"],
            capture_output=True, timeout=5
        )
    except Exception:
        pass


_nl_inst_ref = None  # référence globale pour extinction LEDs au Ctrl+C

def main():
    _setup_logging()
    _stop_modem_manager()
    print("=== NicLink ===")
    start_server(host="127.0.0.1", port=5000)
    time.sleep(2.0)
    webbrowser.open("http://127.0.0.1:5000")
    time.sleep(1.0)
    set_app_state("menu")
    threading.Thread(target=_check_board_at_startup, daemon=True).start()
    try:
        while True:
            action = get_menu_action(timeout=1.0)
            if action is None:
                continue
            atype = action.get("type", "")
            if atype == "mode" and action.get("value") == "pedagogique":
                set_app_state("config")
            elif atype == "mode" and action.get("value") == "humain":
                set_app_state("config_humain")
            elif atype == "mode" and action.get("value") == "analyse":
                set_app_state("game_over", {
                    "title": "Analyse de partie",
                    "result": "Importez un fichier PGN",
                    "history_fen": [],
                    "history_moves": [],
                    "init": {},
                })
            elif atype == "mode" and action.get("value") == "analyse_libre":
                _launch_labo()
            elif atype == "mode" and action.get("value") == "exercices":
                _launch_exercices()
            elif atype == "start_exercice":
                threading.Thread(target=_run_exercice, args=(action,), daemon=True).start()
            elif atype in ("exercice_back",):
                set_app_state("exercices")
                send_event("exercice_back", {})
            elif atype == "start_analyse_libre":
                _launch_analyse_libre(action)
            elif atype == "back":
                set_app_state("menu")
            elif atype == "start":
                _launch_pedagogique(action)
            elif atype == "start_humain":
                _launch_humain(action)
            elif atype == "back_menu":
                set_app_state("menu")
            elif atype == "reconnect_board":
                threading.Thread(target=_check_board_at_startup, daemon=True).start()
            elif atype == "quit":
                print("\nAu revoir !")
                if _nl_inst_ref is not None:
                    try: _nl_inst_ref.turn_off_all_leds()
                    except Exception: pass
                _start_modem_manager()
                sys.exit(0)
    except KeyboardInterrupt:
        print("\nAu revoir !")
        if _nl_inst_ref is not None:
            try:
                _nl_inst_ref.turn_off_all_leds()
            except Exception:
                pass
        _start_modem_manager()
        sys.exit(0)


def _check_board_at_startup():
    for _ in range(100):
        time.sleep(0.1)
        if web_server._app_state == "menu":
            break
    time.sleep(1.0)
    try:
        from nicsoft.niclink import NicLinkManager
        devnull_fd = os.open(os.devnull, os.O_WRONLY)
        old_fd = os.dup(1)
        try:
            os.dup2(devnull_fd, 1)
            _logger = logging.getLogger("NicLink_startup")
            nl = NicLinkManager(refresh_delay=0.1, logger=_logger, thread_sleep_delay=0.1)
        finally:
            os.dup2(old_fd, 1)
            os.close(devnull_fd)
            os.close(old_fd)
        try:
            nl._fen_reader_stop.set()
        except Exception:
            pass
        send_event("board_ok", {})
    except SystemExit as e:
        if "board connection error" in str(e):
            send_event("board_error", {"message": "Échiquier non détecté — vérifiez l'USB et allumez le plateau."})
    except Exception:
        send_event("board_error", {"message": "Échiquier non détecté — vérifiez l'USB et allumez le plateau."})


def _launch_pedagogique(config):
    import json, pathlib
    player  = config.get("player", "Anonyme") or "Anonyme"
    color   = config.get("color", "white")
    level   = int(config.get("level", 5))
    pause   = config.get("pause", "blunder")
    analyse = config.get("analyse_active", True)
    bip     = config.get("bip_active", False)
    engine_type = config.get("engine_type", "stockfish")
    maia_elo    = int(config.get("maia_elo", 1500))
    rodent_elo  = int(config.get("rodent_elo", 800))
    rodent_simple = config.get("rodent_simple", False)
    if color == "random":
        color = random.choice(["white", "black"])
    playing_white = (color == "white")

    # Lire engine_elo et engine_path depuis config.json
    cfg_path = pathlib.Path.home() / "NicLink" / "data" / "config.json"
    engine_elo  = 1500
    engine_path = ""
    if cfg_path.exists():
        try:
            with open(cfg_path, "r", encoding="utf-8") as f:
                cfg = json.load(f)
            engine_elo  = cfg.get("engine_elo", 1500)
            engine_path = cfg.get("engine_path", "")
        except Exception:
            pass

    web_server._app_state = "connecting"
    set_app_state("connecting")
    _error = [False]
    t = threading.Thread(
        target=_run_pedagogique,
        args=(player, playing_white, level, pause, analyse, bip,
              engine_elo, engine_path, engine_type, maia_elo, rodent_elo, rodent_simple, _error),
        daemon=True,
    )
    t.start()
    t.join()
    if _error[0]:
        time.sleep(3.0)
        web_server._app_state = "menu"
        set_app_state("menu")
    elif web_server._app_state != "game_over":
        web_server._app_state = "menu"
        set_app_state("menu")


def _launch_humain(config):
    white = config.get("white", "Anonyme1") or "Anonyme1"
    black = config.get("black", "Anonyme2") or "Anonyme2"
    if config.get("color") == "random":
        if random.random() < 0.5:
            white, black = black, white
    game_type = config.get("game_type", "serieuse")
    web_server._app_state = "connecting"
    set_app_state("connecting")
    _error = [False]
    t = threading.Thread(target=_run_humain, args=(white, black, game_type, _error), daemon=True)
    t.start()
    t.join()
    if _error[0]:
        time.sleep(3.0)
        web_server._app_state = "menu"
        set_app_state("menu")
    elif web_server._app_state == "game_over":
        pass  # fin normale : laisser l'écran game_over visible
    else:
        # back_menu ou autre fin — toujours revenir au menu et renvoyer board_ok
        web_server._app_state = "menu"
        set_app_state("menu")


def _run_pedagogique(player_name, playing_white, level, pause, analyse_active, bip_active,
                     engine_elo, engine_path, engine_type="stockfish", maia_elo=1500,
                     rodent_elo=800, rodent_simple=False, _error=None):
    from nicsoft.niclink import NicLinkManager
    from nicsoft.play_pedagogique.__main__ import Game, load_config
    from nicsoft.web.server import get_action

    config = load_config()
    config["pedagogique_pause"] = pause
    nl_inst = None
    try:
        devnull_fd = os.open(os.devnull, os.O_WRONLY)
        old_fd = os.dup(1)
        try:
            os.dup2(devnull_fd, 1)
            _logger = logging.getLogger("NicLink")
            nl_inst = NicLinkManager(refresh_delay=0.1, logger=_logger, thread_sleep_delay=0.1)
        finally:
            os.dup2(old_fd, 1)
            os.close(devnull_fd)
            os.close(old_fd)
        print("NicLink OK")
        global _nl_inst_ref
        _nl_inst_ref = nl_inst
        _wait_initial_position_web(nl_inst)
        web_server._app_state = "playing"
        set_app_state("playing")

        if engine_type == "maia":
            engine_label = f"Maia {maia_elo}"
        elif engine_type == "rodent":
            engine_label = f"Rodent {rodent_elo}" + (" (Simple)" if rodent_simple else "")
        else:
            engine_label = f"Stockfish ~{engine_elo}elo"

        game = Game(
            nl_inst, playing_white,
            stockfish_level=level,
            default_game_type="pedagogique",
            turn_signal=config.get("turn_signal", "both"),
            pedagogique_pause=pause,
            engine_elo=engine_elo,
            analyse_active=analyse_active,
            bip_active=bip_active,
            engine_path=engine_path,
            engine_type=engine_type,
            maia_elo=maia_elo,
            rodent_elo=rodent_elo,
            rodent_simple=rodent_simple,
        )
        game.player_name    = player_name
        game.move_gaps      = []
        game.last_move_time = time.time()
        send_event("init", {
            "fen":         chess.STARTING_FEN,
            "player":      player_name,
            "color":       "white" if playing_white else "black",
            "level":       level,
            "elo":         maia_elo if engine_type == "maia" else (rodent_elo if engine_type == "rodent" else engine_elo),
            "pause":       pause,
            "analyse":     analyse_active,
            "opponent":    engine_label,
            "engine_type": engine_type,
        })
        from nicsoft.web.server import action_queue as _aq
        while not _aq.empty():
            try: _aq.get_nowait()
            except Exception: break
        game.save_pgn_tmp()
        print(f"Partie : {player_name} vs {engine_label}")
        game.start()
    except SystemExit as e:
        if "board connection error" in str(e):
            print("Erreur : échiquier non détecté.")
            if _error: _error[0] = True
            send_event("board_error", {"message": "Échiquier non détecté — vérifiez l'USB et allumez le plateau."})
    except Exception as e:
        print(f"Erreur connexion échiquier : {e}")
        import traceback; traceback.print_exc()
        if _error: _error[0] = True
        send_event("board_error", {"message": "Échiquier non détecté — vérifiez l'USB et allumez le plateau."})
    finally:
        if nl_inst:
            try: nl_inst.turn_off_all_leds()
            except Exception: pass
        if web_server._app_state != "game_over":
            web_server._app_state = "menu"


def _run_humain(white_name, black_name, game_type, _error=None):
    from nicsoft.niclink import NicLinkManager
    from nicsoft.play_human.__main__ import GameWeb
    nl_inst = None
    try:
        devnull_fd = os.open(os.devnull, os.O_WRONLY)
        old_fd = os.dup(1)
        try:
            os.dup2(devnull_fd, 1)
            _logger = logging.getLogger("NicLink_humain")
            nl_inst = NicLinkManager(refresh_delay=0.1, logger=_logger, thread_sleep_delay=0.1)
        finally:
            os.dup2(old_fd, 1)
            os.close(devnull_fd)
            os.close(old_fd)

        _wait_initial_position_web(nl_inst)
        global _nl_inst_ref
        _nl_inst_ref = nl_inst
        web_server._game_state["history"]     = []
        web_server._game_state["history_fen"] = ["rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR"]

        game = GameWeb(nl_inst, white_name=white_name, black_name=black_name,
                       default_game_type=game_type)
        game.move_gaps      = []
        game.last_move_time = time.time()

        send_event("init_hh", {"fen": chess.STARTING_FEN, "white": white_name, "black": black_name})
        set_app_state("playing")

        from nicsoft.web.server import action_queue as _aq
        while not _aq.empty():
            try: _aq.get_nowait()
            except Exception: break

        game.save_pgn_tmp()
        print(f"Partie : {white_name} vs {black_name}")
        game.start()
        if game.game_over and web_server._app_state != "game_over":
            web_server._app_state = "game_over"

    except SystemExit:
        pass  # fin normale via sys.exit(0) dans _traiter_abandon ou _end_game
    except Exception as e:
        print(f"Erreur : {e}")
        import traceback; traceback.print_exc()
        if _error: _error[0] = True
        send_event("board_error", {"message": "Échiquier non détecté."})
    finally:
        if nl_inst:
            try: nl_inst.turn_off_all_leds()
            except Exception: pass
        if web_server._app_state not in ("game_over", "menu"):
            web_server._app_state = "menu"


def _wait_initial_position_web(nl_inst, timeout: float = 300.0):
    import chess as _chess
    INITIAL_FEN = _chess.Board().board_fen()
    first_check = True
    consecutive_errors = 0
    t_start = time.time()
    while True:
        try:
            raw_fen = nl_inst.get_fen()
            consecutive_errors = 0
        except Exception:
            consecutive_errors += 1
            if consecutive_errors >= 5 or (time.time() - t_start) >= timeout:
                raise ConnectionError("Échiquier non détecté.")
            time.sleep(0.2)
            continue
        board_fen = raw_fen.strip().split()[0] if raw_fen else ""
        if not board_fen:
            consecutive_errors += 1
            if consecutive_errors >= 5 or (time.time() - t_start) >= timeout:
                raise ConnectionError("Échiquier non détecté.")
            time.sleep(0.2)
            continue
        if board_fen == INITIAL_FEN:
            nl_inst.turn_off_all_leds()
            set_app_state("connecting")
            time.sleep(0.3)
            return
        if first_check:
            first_check = False
            try: nl_inst.signal_lights(1)
            except Exception: pass
        set_app_state("position_initiale", {"fen": board_fen})
        time.sleep(0.5)


def _launch_exercices():
    """Affiche l'écran de sélection des exercices."""
    from nicsoft.exercices.__main__ import get_ouvertures
    web_server._app_state = "exercices"
    set_app_state("exercices", {"ouvertures": get_ouvertures()})


def _run_exercice(config: dict) -> None:
    """Lance une session d'exercice ouverture."""
    from nicsoft.niclink import NicLinkManager
    from nicsoft.exercices.__main__ import ExerciceSession, OUVERTURES
    import logging as _log

    ouverture_id = config.get("ouverture_id", "")
    ouverture = next((o for o in OUVERTURES if o["id"] == ouverture_id), None)
    if not ouverture:
        send_event("board_error", {"message": f"Ouverture '{ouverture_id}' introuvable."})
        return

    human_color = config.get("human_color", "white")
    variete     = int(config.get("variete", 3))

    nl_inst = None
    try:
        devnull_fd = os.open(os.devnull, os.O_WRONLY)
        old_fd = os.dup(1)
        try:
            os.dup2(devnull_fd, 1)
            _logger = _log.getLogger("NicLink_exercice")
            nl_inst = NicLinkManager(refresh_delay=0.1, logger=_logger, thread_sleep_delay=0.1)
        finally:
            os.dup2(old_fd, 1)
            os.close(devnull_fd)
            os.close(old_fd)

        print("NicLink OK — Exercice ouverture")
        global _nl_inst_ref
        _nl_inst_ref = nl_inst

        web_server._app_state = "exercice_running"
        set_app_state("exercice_running")

        send_event("exercice_init", {
            "ouverture":   ouverture,
            "human_color": human_color,
            "variete":     variete,
        })

        session = ExerciceSession(nl_inst, ouverture, human_color, variete)
        session.run()

    except Exception as e:
        print(f"[EXERCICE] Erreur : {e}")
        import traceback; traceback.print_exc()
        send_event("board_error", {"message": "Échiquier non détecté."})
    finally:
        if nl_inst:
            try: nl_inst.turn_off_all_leds()
            except Exception: pass
        if web_server._app_state not in ("menu", "exercices"):
            web_server._app_state = "exercices"
            set_app_state("exercices", {"ouvertures": []})


def _launch_labo():
    """Lance le labo directement — polling continu du plateau physique."""
    web_server._app_state = "labo"
    set_app_state("labo")
    threading.Thread(target=_poll_board_fen_labo, daemon=True).start()
    threading.Thread(target=_run_labo_session, daemon=True).start()


def _poll_board_fen_labo():
    """Envoie le FEN physique au navigateur toutes les 300ms pendant le labo."""
    from nicsoft.niclink import NicLinkManager
    import logging as _log
    nl = None
    try:
        devnull_fd = os.open(os.devnull, os.O_WRONLY)
        old_fd = os.dup(1)
        try:
            os.dup2(devnull_fd, 1)
            nl = NicLinkManager(refresh_delay=0.1, logger=_log.getLogger("NL_labo_poll"),
                                thread_sleep_delay=0.1)
        finally:
            os.dup2(old_fd, 1)
            os.close(devnull_fd)
            os.close(old_fd)
        global _nl_inst_ref
        _nl_inst_ref = nl
        while web_server._app_state == "labo":
            try:
                raw = nl.get_fen()
                fen = raw.strip().split()[0] if raw else ""
                if fen:
                    send_event("board_fen_update", {"fen": fen})
            except Exception:
                pass
            time.sleep(0.3)
    except Exception as e:
        print(f"[LABO POLL] Erreur : {e}")
    finally:
        if nl:
            try: nl._fen_reader_stop.set()
            except Exception: pass


def _make_labo_session(nl_inst, config: dict):
    """Crée une LaboSession depuis la config courante."""
    from nicsoft.labo.__main__ import LaboSession
    from nicsoft.game.engine_manager import find_stockfish
    engine_path = ""
    try:
        import json, pathlib
        cfg_path = pathlib.Path.home() / "NicLink" / "data" / "config.json"
        if cfg_path.exists():
            with open(cfg_path) as f:
                cfg = json.load(f)
            engine_path = cfg.get("engine_path", "")
    except Exception:
        pass
    if not engine_path:
        engine_path = find_stockfish() or "stockfish"

    # camp moteur = opposé du camp humain
    human = config.get("human_color", "white")
    engine_color = "black" if human == "white" else "white"

    return LaboSession(
        nl_inst,
        engine_color   = engine_color,
        engine_elo     = config.get("engine_elo", 1500),
        analyse_active = config.get("analyse", True),
        engine_path    = engine_path,
        engine_type    = config.get("engine_type", "stockfish"),
        maia_elo       = config.get("maia_elo", 1500),
        rodent_elo     = config.get("rodent_elo", 800),
    )


def _run_labo_session():
    """Boucle principale du labo."""
    from nicsoft.web.server import get_action as _get_action

    # Attendre que nl_inst_ref soit disponible
    for _ in range(50):
        if _nl_inst_ref is not None:
            break
        time.sleep(0.1)

    nl = _nl_inst_ref
    if nl is None:
        print("[LABO] Échiquier non disponible")
        return

    labo_config = {
        "human_color": "white",
        "engine_type": "stockfish",
        "engine_elo":  1500,
        "maia_elo":    1500,
        "rodent_elo":  800,
        "analyse":     True,
    }

    try:
        session = _make_labo_session(nl, labo_config)
    except Exception as e:
        print(f"[LABO] Erreur création session : {e}")
        return

    # Lancer le watcher plateau
    session._running = True
    threading.Thread(target=session.board_watcher, daemon=True).start()

    # Synchroniser avec le plateau physique actuel
    session.sync_from_physical()

    # Envoyer init
    send_event("labo_init", {
        "fen":          session.board.board_fen(),
        "human_color":  labo_config["human_color"],
        "engine_label": session.engine_label,
        "analyse":      labo_config["analyse"],
    })

    while web_server._app_state == "labo":
        action = _get_action(timeout=0.5)
        if action is None:
            continue
        atype = action.get("type", "")

        if atype == "back_menu":
            session.quit()
            web_server._app_state = "menu"
            set_app_state("menu")
            return

        elif atype == "labo_set_config":
            engine_changed = False
            color_changed  = False
            for k in ("human_color", "engine_type", "engine_elo", "maia_elo", "rodent_elo", "analyse"):
                if k in action and action[k] != labo_config.get(k):
                    if k == "human_color":
                        color_changed = True
                    else:
                        engine_changed = True
                    labo_config[k] = action[k]

            if color_changed and not engine_changed:
                new_ec = chess.BLACK if labo_config["human_color"] == "white" else chess.WHITE
                session.engine_color = new_ec
                send_event("labo_init", {
                    "fen":          session.board.board_fen(),
                    "human_color":  labo_config["human_color"],
                    "engine_label": session.engine_label,
                    "analyse":      labo_config["analyse"],
                })
                session._send_position()
                # Si auto ON et c'est maintenant au moteur → jouer
                if session._auto_on and session.board.turn == new_ec and not session._engine_busy:
                    session.do_engine_play()

            elif engine_changed:
                old_board   = session.board
                old_history = session._fen_history[:]
                session._running = False
                time.sleep(0.2)
                try:
                    session = _make_labo_session(nl, labo_config)
                    session.board         = old_board
                    session._fen_history  = old_history
                    nl.game_board         = session.board.copy()
                    session._running      = True
                    threading.Thread(target=session.board_watcher, daemon=True).start()
                    send_event("labo_init", {
                        "fen":          session.board.board_fen(),
                        "human_color":  labo_config["human_color"],
                        "engine_label": session.engine_label,
                        "analyse":      labo_config["analyse"],
                    })
                    session._send_position()
                except Exception as e:
                    print(f"[LABO] Erreur recréation : {e}")

        elif atype == "best_move":
            # Vider les best_move en attente dans la queue (clics multiples)
            from nicsoft.web.server import action_queue as _aq
            while not _aq.empty():
                try:
                    peek = _aq.queue[0]
                    if peek.get("type") == "best_move":
                        _aq.get_nowait()
                    else:
                        break
                except Exception:
                    break
            session.do_best_move()

        elif atype == "engine_auto":
            val = action.get("value", not session._auto_on)
            session._auto_on = val
            send_event("labo_auto", {"auto": val})
            if val:
                # Toujours synchroniser depuis le plateau physique au démarrage Auto
                # pour s'assurer que le board et le tour sont corrects
                session.sync_from_physical(turn=labo_config.get("active_turn", session.active_turn))
                time.sleep(0.1)
                if session.board.turn == session.engine_color and not session._engine_busy:
                    session.do_engine_play()

        elif atype == "analyse_position":
            session.do_analyse()

        elif atype == "undo_labo":
            session.do_undo()

        elif atype == "source_physique":
            _copy_cancel.set()
            time.sleep(0.1)
            turn = action.get("turn", session.active_turn)
            session.sync_from_physical(turn=turn)
            time.sleep(0.1)  # laisser le board se mettre à jour
            if session._auto_on and session.board.turn == session.engine_color and not session._engine_busy:
                session.do_engine_play()

        elif atype == "labo_set_turn":
            turn = action.get("turn", "white")
            labo_config["active_turn"] = turn
            session.active_turn = turn

        elif atype == "set_analyse":
            session.analyse_active = action.get("value", True)
            try: session.engine.analyse_active = session.analyse_active
            except Exception: pass

        elif atype == "labo_copy_to_board":
            target_fen = action.get("fen", "")
            if target_fen:
                # Lancer la copie en thread séparé pour rester réactif
                def _copy_thread(fen=target_fen):
                    _do_copy_to_board(fen)
                    if not _copy_cancel.is_set():
                        # Copie réussie — syncer la session
                        try:
                            session.set_board_from_fen(fen)
                        except Exception as e:
                            print(f"[LABO] set_board_from_fen : {e}")
                threading.Thread(target=_copy_thread, daemon=True).start()

    session.quit()
    web_server._app_state = "menu"
    set_app_state("menu")


_copy_cancel = threading.Event()  # flag pour annuler _do_copy_to_board


def _do_copy_to_board(target_fen: str) -> None:
    """Guide l'utilisateur pour reproduire un FEN cible sur le plateau physique."""
    global _nl_inst_ref
    nl = _nl_inst_ref
    if nl is None:
        return
    target = target_fen.strip().split()[0] if " " in target_fen else target_fen
    _copy_cancel.clear()

    send_event("labo_copy_start", {"target_fen": target})

    while not _copy_cancel.is_set():
        try:
            raw = nl.get_fen()
            board_fen = raw.strip().split()[0] if raw else ""
            if board_fen == target:
                nl.turn_off_all_leds()
                send_event("position_ok", {"fen": target})
                return
            send_event("position_error", {
                "expected_fen": target,
                "physical_fen": board_fen,
            })
        except Exception:
            pass
        time.sleep(0.5)
    # Annulé — éteindre les LEDs
    nl.turn_off_all_leds()


def _poll_board_fen():
    """Envoie le FEN physique au navigateur toutes les 500ms pendant config_analyse_libre."""
    from nicsoft.niclink import NicLinkManager
    import logging as _log
    nl = None
    try:
        devnull_fd = os.open(os.devnull, os.O_WRONLY)
        old_fd = os.dup(1)
        try:
            os.dup2(devnull_fd, 1)
            nl = NicLinkManager(refresh_delay=0.1, logger=_log.getLogger("NL_poll"), thread_sleep_delay=0.1)
        finally:
            os.dup2(old_fd, 1)
            os.close(devnull_fd)
            os.close(old_fd)
        while web_server._app_state == "config_analyse_libre":
            try:
                raw = nl.get_fen()
                fen = raw.strip().split()[0] if raw else ""
                if fen:
                    send_event("board_fen_update", {"fen": fen})
            except Exception:
                pass
            time.sleep(0.5)
    except Exception as e:
        print(f"[POLL] Erreur lecture FEN : {e}")
    finally:
        if nl:
            try:
                nl._fen_reader_stop.set()
            except Exception:
                pass


def _launch_analyse_libre(config):
    player       = config.get("player", "Anonyme") or "Anonyme"
    color        = config.get("color", "white")
    start_fen    = config.get("fen", chess.STARTING_FEN)
    pause        = config.get("pause", "blunder")
    analyse      = config.get("analyse_active", True)
    bip          = config.get("bip_active", False)
    engine_type  = config.get("engine_type", "stockfish")
    maia_elo     = int(config.get("maia_elo", 1500))
    rodent_elo   = int(config.get("rodent_elo", 800))
    rodent_simple = config.get("rodent_simple", False)

    if color == "random":
        color = random.choice(["white", "black"])
    playing_white = (color == "white")

    import json, pathlib
    cfg_path = pathlib.Path.home() / "NicLink" / "data" / "config.json"
    engine_elo  = 1500
    engine_path = ""
    if cfg_path.exists():
        try:
            with open(cfg_path, "r", encoding="utf-8") as f:
                cfg = json.load(f)
            engine_elo  = cfg.get("engine_elo", 1500)
            engine_path = cfg.get("engine_path", "")
        except Exception:
            pass

    web_server._app_state = "connecting"
    set_app_state("connecting")
    _error = [False]
    t = threading.Thread(
        target=_run_analyse_libre,
        args=(player, playing_white, start_fen, pause, analyse, bip,
              engine_elo, engine_path, engine_type, maia_elo, rodent_elo, rodent_simple, _error),
        daemon=True,
    )
    t.start()
    t.join()
    if _error[0]:
        time.sleep(3.0)
        web_server._app_state = "menu"
        set_app_state("menu")
    elif web_server._app_state != "game_over":
        web_server._app_state = "menu"
        set_app_state("menu")


def _run_analyse_libre(player_name, playing_white, start_fen, pause, analyse_active, bip_active,
                       engine_elo, engine_path, engine_type, maia_elo, rodent_elo, rodent_simple, _error=None):
    from nicsoft.niclink import NicLinkManager
    from nicsoft.labo.__main__ import LaboSession

    nl_inst = None
    try:
        devnull_fd = os.open(os.devnull, os.O_WRONLY)
        old_fd = os.dup(1)
        try:
            os.dup2(devnull_fd, 1)
            _logger = logging.getLogger("NicLink_libre")
            nl_inst = NicLinkManager(refresh_delay=0.1, logger=_logger, thread_sleep_delay=0.1)
        finally:
            os.dup2(old_fd, 1)
            os.close(devnull_fd)
            os.close(old_fd)

        print("NicLink OK")
        global _nl_inst_ref
        _nl_inst_ref = nl_inst

        # Attendre que le plateau corresponde au FEN de départ
        _wait_position_web(nl_inst, start_fen)

        web_server._app_state = "labo"
        set_app_state("labo")

        if engine_type == "maia":
            engine_label = f"Maia {maia_elo}"
        elif engine_type == "rodent":
            engine_label = f"Rodent {rodent_elo}"
        else:
            engine_label = f"Stockfish ~{engine_elo}elo"

        fen_short = start_fen.split()[0] if " " in start_fen else start_fen

        session = LaboSession(
            nl_inst,
            human_color="white" if playing_white else "black",
            start_fen=start_fen,
            engine_elo=engine_elo,
            analyse_active=analyse_active,
            engine_path=engine_path,
            engine_type=engine_type,
            maia_elo=maia_elo,
            rodent_elo=rodent_elo,
            rodent_simple=rodent_simple,
        )

        from nicsoft.web.server import action_queue as _aq
        while not _aq.empty():
            try: _aq.get_nowait()
            except Exception: break

        send_event("labo_init", {
            "fen":          fen_short,
            "player":       player_name,
            "human_color":  "white" if playing_white else "black",
            "engine_label": engine_label,
            "analyse":      analyse_active,
        })

        print(f"Labo : {player_name} — {engine_label} depuis {fen_short[:30]}...")
        session.start()

    except SystemExit:
        pass
    except Exception as e:
        print(f"Erreur labo : {e}")
        import traceback; traceback.print_exc()
        if _error: _error[0] = True
        send_event("board_error", {"message": "Échiquier non détecté."})
    finally:
        if nl_inst:
            try: nl_inst.turn_off_all_leds()
            except Exception: pass
        if web_server._app_state not in ("menu",):
            web_server._app_state = "menu"


def _wait_position_web(nl_inst, target_fen: str, timeout: float = 300.0):
    """Attend que le plateau physique corresponde au FEN cible."""
    target = target_fen.strip().split()[0] if " " in target_fen else target_fen
    t_start = time.time()
    first_check = True
    while True:
        try:
            raw = nl_inst.get_fen()
            board_fen = raw.strip().split()[0] if raw else ""
        except Exception:
            time.sleep(0.2)
            continue
        if board_fen == target:
            nl_inst.turn_off_all_leds()
            return
        if first_check:
            first_check = False
        send_event("position_error", {
            "expected_fen": target,
            "physical_fen": board_fen,
        })
        if (time.time() - t_start) >= timeout:
            raise ConnectionError("Timeout — position non atteinte.")
        time.sleep(0.5)


if __name__ == "__main__":
    main()
